<?php

class CartaItem extends Omeka_Record_AbstractRecord
{
    public $id;
    public $name;
    public $width;
    public $height;
    public $baselayer;
    public $layergroup;
    public $pointers;
    public $type;   
}