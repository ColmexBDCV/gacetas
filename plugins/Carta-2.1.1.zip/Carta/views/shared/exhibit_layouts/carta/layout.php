<?php 

 $tobj = new Omeka_View_Helper_Shortcodes;
 
echo $tobj->shortcodes($text);
?>