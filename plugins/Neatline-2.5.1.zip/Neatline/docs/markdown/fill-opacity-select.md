## Fill Opacity (Selected)

The opacity of the "body" of points and polygons on the map (inside the lines, not including the lines themselves) **when the record is highlighted or selected** - for example, when the cursor hovers or clicks on the shape.

To change the opacity, type directly into the input or change the value smoothly down by clicking and moving the mouse up or down on the page.

  - Min: `0.00`
  - Max: `1.00`
