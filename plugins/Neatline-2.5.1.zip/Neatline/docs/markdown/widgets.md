## Widgets

The collection of pluggable user-interface widgets that the record is visible on. For example, if the Waypoints extension is installed, selecting the "Waypoints" option will cause the record to appear in the list of waypoints. Or, if the SIMILE Timeline widget is installed, selecting "SIMILE Timeline" will cause the record to be displayed on the timeline if date information is provided.
