## Coverage

The raw vector geometry data for the record, stored as [WKT (Well-Known Text)][wkt]. This field is automatically updated by the drawing tools, but it's also possible to import existing data - just paste it directly into the input, and the geometry will immediately appear on the map.

[wkt]: http://en.wikipedia.org/wiki/Well_Known_Text
