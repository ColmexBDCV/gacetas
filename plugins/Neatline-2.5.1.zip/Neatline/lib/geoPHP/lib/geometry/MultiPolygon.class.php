<?php
/**
 * MultiPolygon: A collection of Polygons
 */
class MultiPolygon extends geoPHP_Collection 
{
  protected $geom_type = 'MultiPolygon';
}
